# AI Agency Maturity Framework

## Purpose

This document defines the AI Agency Maturity Framework used by the repository.
It is intended to be read by both humans and AI agents working with the project.

The framework describes increasing levels of responsibility and authority that can
be delegated to an AI system. It distinguishes the level of responsibility from
the mechanisms through which the system exercises that responsibility.

## The Framework at a Glance

The framework has six dimensions:

1. **Directive** - What goal or outcome is the system responsible for achieving, and within what scope and constraints?
2. **Context** - What information and environment does the system have available?
3. **Reasoning** - What does the system need to figure out?
4. **Agency** - What decisions and actions is the system authorized to make?
5. **Experimentation** - What can the system deliberately try to discover what works?
6. **Learning** - What can the system learn from results and carry forward?

Directive establishes the goal or outcome the AI system is responsible for
achieving, including the scope and constraints of that responsibility. Agency
establishes its decision-making and action authority. Context, Reasoning,
Experimentation, and Learning describe the capabilities supporting execution of
that responsibility, subject to applicable permissions and controls.

## Executive Management Principle: Responsibility-Authority-Capability Alignment

Effective AI delegation requires **alignment among responsibility, authority,
and capability**. These are three complementary management concepts, not three
additional maturity dimensions:

| Alignment element | Framework dimension(s) | Executive question |
|---|---|---|
| **Responsibility** | **Directive** | What goal or outcome is the system responsible for achieving, and within what scope and constraints? |
| **Authority** | **Agency** | What decisions and actions is the system permitted to make or undertake? |
| **Capability** | **Context** | What information and environmental access are available? |
| **Capability** | **Reasoning** | What must the system be able to interpret, plan, coordinate, or optimize? |
| **Capability** | **Experimentation** | What alternatives can the system test to discover what works? |
| **Capability** | **Learning** | What can the system learn from results and carry forward? |

**Experimentation and Learning require a qualification:** they describe potential
capabilities, but their use, scope, and consequences may also be restricted by
Agency and by the Directive's constraints. In particular, the ability to run an
experiment does not by itself confer permission to run it, and the ability to
learn does not imply permission to alter production behavior.

Misalignment creates managerial problems:

- **Responsibility exceeds authority:** The system cannot complete its assigned
  work without approval, escalation, or additional permissions.
- **Responsibility exceeds capability:** The system lacks sufficient context,
  reasoning, or other capabilities to achieve the assigned outcome reliably.
- **Authority exceeds what the responsibility and risk justify:** The system has
  unnecessary discretion or access, creating avoidable exposure.
- **Capability exceeds authority:** Some technically possible actions remain
  intentionally restricted; this can be an appropriate governance choice.

The objective is **not maximum autonomy or progression to Stage 6 in every
process**. It is to match delegated responsibility, authority, and capability
to the business objective, operational readiness, and acceptable risk. Humans
and organizations retain ultimate accountability for delegated AI operations.

This is **organizational alignment of delegated agency**. It complements, but
is distinct from, technical AI alignment (whether system behavior follows
intended objectives, constraints, and human values).

## Maturity Levels

| Stage | Directive | Context | Reasoning | Agency | Experimentation | Learning |
|---|---|---|---|---|---|---|
| **1 - Manual** | Human-directed | Human has the relevant context | Human reasoning | Human decides and acts | No agent experimentation | Humans learn from experience |
| **2 - Automated** | Workflow | Process context | **Execution** - Which predefined action or path applies? | **Reactive** - Executes predefined rules | No autonomous experimentation | No substantive agentic learning |
| **3 - Assisted** | Task | Case context | **Interpretation** - What does the situation mean, and what should happen? | **Advisory** - Recommends; human decides and acts | **Suggest experiments** for a human to conduct | Learn to improve **recommendations** |
| **4 - Agentic** | Task | Operational context | **Planning** - How can the defined task be accomplished? | **Discretionary** - Selects and executes actions within authorized boundaries | Experiment to improve **task execution** | Learn which plans, steps, tools, and strategies work best |
| **5 - Autonomous** | Objective | Business context | **Orchestration** - What work must be coordinated to achieve the objective? | **Adaptive** - Coordinates and adjusts actions across tasks | Experiment to refine the **policy governing the flow** | Learn which tasks, workflows, parameters, and combinations best achieve the objective |
| **6 - Self-optimizing** | Business Outcome | Organizational/system context | **Optimization** - How should the operation itself change? | **Transformative** - Authorized to change the operation | Experiment to refine the **flow/operation itself** | Learn which workflows, rules, resources, and operating strategies produce better outcomes |

## Core Progressions

### Directive

The level of responsibility delegated to the AI progresses from **executing prescribed work** to **managing an operation to achieve a business outcome**:

**Workflow -> Task -> Objective -> Business Outcome**

The stages can therefore be summarized as:

- **Stage 2 - Automated:** Execute a prescribed workflow.
- **Stage 3 - Assisted:** Support the human in completing a defined task.
- **Stage 4 - Agentic:** Accomplish a defined task.
- **Stage 5 - Autonomous:** Pursue a defined objective.
- **Stage 6 - Self-optimizing:** Manage and continuously improve the operation to achieve a business outcome.

**Directive — Establishes the goal or outcome the AI system is responsible for achieving, including the scope and constraints of that responsibility.**

**Goals are concrete instantiations of the Directive**: they express particular results to pursue,
whether assigned externally or derived by the system as subordinate goals.
Every derived goal must remain consistent with the governing Directive and its
constraints. A goal does not itself grant authority to take actions; that
permission is defined by the **Agency** dimension.

#### Directive, Goal, Reasoning, and Agency

- **Directive:** What goal or outcome is the system responsible for achieving, and within what scope and constraints?
- **Goal:** What particular result operationalizes the Directive?
- **Reasoning:** What must the system figure out to achieve that result?
- **Agency:** What decisions and actions is the system authorized to undertake?

**Stage 4 example - Student advising:** The Directive delegates responsibility
for completing a student-advising task; a concrete goal is to book an advising
appointment for a particular student. Reasoning determines the necessary steps
and tools; Agency permits the system to select and execute authorized actions.

**Stage 5 example - Advising operations:** The Directive delegates responsibility
for improving appointment bookings. The system may derive subordinate goals,
such as following up with particular students or coordinating adviser availability,
while remaining within the Directive and its delegated authority.

### Context

As agency increases, the required context broadens:

**Process -> Case -> Operational -> Business -> Organizational/System**

Higher agency requires broader context while retaining the context available at
lower stages.

### Reasoning

The scope of reasoning progresses as:

**Execution -> Interpretation -> Planning -> Orchestration -> Optimization**

The questions become progressively broader and more abstract:

- **Execution:** Which predefined action or path applies?
- **Interpretation:** What does this situation mean, and what should happen?
- **Planning:** How can a defined task be accomplished?
- **Orchestration:** What work must be coordinated to achieve the objective?
- **Optimization:** How should the operation itself change?

### Agency

The corresponding progression in delegated decision-making and action authority is:

**Execute prescribed actions -> Recommend actions -> Select and execute actions -> Coordinate and adapt actions -> Change the operation**

- **Reactive (Stage 2):** Execute predefined actions under prescribed rules.
- **Advisory (Stage 3):** Recommend actions; a human retains decision and execution authority.
- **Discretionary (Stage 4):** Select and execute actions within authorized boundaries to accomplish a defined task.
- **Adaptive (Stage 5):** Coordinate and adjust actions across tasks to pursue an objective within authorized boundaries.
- **Transformative (Stage 6):** Change the operation itself, including its workflows and operating mechanisms, within delegated authority.

Agency concerns **permission to decide and act**, not the goal itself or the reasoning used to select a course of action. Planning is part of the **Reasoning** dimension; authority to select and execute a plan is part of **Agency**.

The key distinction is:

> **Directive = what responsibility is delegated.**
>
> **Agency = what authority is delegated.**

### The Critical Stage 4 -> Stage 5 Transition

**Stage 4 - Agentic**

> Accomplish this task.

The agent reasons about how the task should be performed and has discretion to select and execute actions within its authorized boundaries.

**Stage 5 - Autonomous**

> Achieve this objective.

The agent reasons about what work is needed and has authority to coordinate and adapt actions across tasks within its authorized boundaries.

The key shift is therefore:

**How do I do the task? -> What work needs to be done?**

## Experimentation and Learning

Experimentation and learning are mechanisms that operate across the maturity
levels rather than separate maturity stages.

### Experimentation

The role of experimentation expands with agency:

- **Stage 2 - Automated:** No autonomous experimentation; execute known rules.
- **Stage 3 - Assisted:** Suggest experiments for a human to run.
- **Stage 4 - Agentic:** Conduct experiments to discover better ways to perform a task.
- **Stage 5 - Autonomous:** Conduct experiments to discover better ways to achieve an objective.
- **Stage 6 - Self-optimizing:** Conduct experiments to discover better ways to operate.

### Learning

The object of learning expands with agency:

**Recommendation -> Task execution -> Objective pursuit -> Operation**

More specifically:

- **Stage 2:** No substantive agentic learning; rules/workflows remain fixed.
- **Stage 3:** Learn to improve recommendations.
- **Stage 4:** Learn which plans, steps, tools, and execution strategies work best for a defined task.
- **Stage 5:** Learn which tasks, workflows, parameters, and combinations of actions best achieve an objective.
- **Stage 6:** Learn which workflows, rules, resources, and operating strategies produce better business outcomes.

## The Object of Improvement

A useful way to understand the progression is to identify what the system is
trying to improve through experimentation and learning:

**Recommendation -> Task execution -> Policy -> Flow/Operation**

This provides a particularly clear distinction among the later stages:

### Stage 4 - Improve task execution

The agent is given a defined task and determines how to perform it.

**Question:**

> How can I execute this task better?

### Stage 5 - Improve policy

The agent is given an objective and experiments with the policy governing the
existing flow.

**Question:**

> What policy should govern how the work is performed to achieve the objective?

### Stage 6 - Improve flow/operation

The agent is given a business outcome and can experiment with the flow and the
operating mechanisms themselves.

**Question:**

> How should the operation itself be structured and changed to achieve the
> business outcome?

A concise formulation is:

> **Stage 5 refines the policy governing the flow.**
>
> **Stage 6 refines the flow itself.**

This is a shorthand for the broader Stage 5 and Stage 6 definitions. The
boundary is one of **delegated responsibility and authority**, not merely the
technical ability to propose a change: Stage 5 may adjust authorized policies
within the existing operating model; Stage 6 is responsible for improving, and
is authorized to change, the operating model itself within defined boundaries.
Stage 6 may also change rules, resources, and other operating mechanisms.

## Reasoning, Agency, Experimentation, Learning, and Adaptation

These concepts should remain distinct.

**Reasoning** - What could I figure out?

**Agency** - What can I decide and do?

**Experimentation** - What can I deliberately try?

**Learning** - What can I learn from the result?

**Adaptation** - What should I do differently next time?

A useful generic loop is:

```text
Observe
   |
Reason
   |
Propose
   |
Experiment
   |
Observe result
   |
Evaluate
   |
Learn from evidence
   |
Adapt
   |
Repeat
```

Experimentation is therefore a **learning mechanism**, while learning is a
capability that can occur at every stage. What changes with maturity is the
scope and consequence of what is being experimented with and learned.

## Important Relationship Between Agency and Learning

Agency does **not** require experimentation or learning.

An agent can have agency by having authority to decide and act within its
assigned boundaries.

However:

> **Agency enables experimentation; experimentation enables experiential
> learning; learning enables adaptation.**

Thus:

- **Agency without experimentation:** The system can decide and act, but may simply execute what it currently believes is best.
- **Agency + experimentation:** The system can deliberately test alternatives.
- **Agency + experimentation + learning:** The system can use evidence from experiments to change future behavior.

Do not describe an agent as lacking agency merely because it does not learn from
experimentation. The Experimentation and Learning entries in the maturity table
characterize the **increasing scope of these capabilities**, where available and
authorized; they are not mandatory activities for every implementation at a
given stage. Maturity still describes all six dimensions together, including
the capabilities needed to exercise delegated responsibility and authority.

## Application to This Repository

The business-process simulation in this repository is intended to demonstrate
movement from Stage 5 toward Stage 6.

The process is:

**Student inquiry -> Outreach -> Advising call booking**

The artifact being optimized is the **workflow policy**, not the student,
LLM, simulator, or Python implementation.

The current experimentation environment primarily changes policy variables such
as:

- same-day outreach threshold
- follow-up timing
- maximum touches
- human-escalation threshold
- segmentation/personalization
- booking threshold
- other bounded workflow parameters

These are primarily **Stage 5** experiments because they refine the policy that
governs an existing operating flow.

A fuller **Stage 6** system would be able to experiment with the structure of the
flow itself - for example, changing how work is routed between automated outreach,
human advising, nurture processes, and scheduling.

Therefore, when analyzing this repository, distinguish:

```text
Stage 5
Policy optimization
     |
Refine the rules/parameters governing the flow

Stage 6
Flow/operation optimization
     |
Refine the structure and operating mechanisms of the flow itself
```

## Alignment Check When Assigning an AI System

For any proposed deployment or change in maturity level, evaluate:

1. **Responsibility / Directive:** What outcome, constraints, and success criteria
   have been assigned?
2. **Authority / Agency:** Are the allowed decisions and actions sufficient, but
   no broader than justified, to fulfill that responsibility?
3. **Capability / Context, Reasoning, Experimentation, Learning:** Does the system
   have the information and abilities required? Which capabilities may be used
   under the assigned permissions?
4. **Governance:** Where are human approval, monitoring, escalation, auditability,
   and accountability required?

A higher maturity label is not evidence of better alignment. The appropriate
stage depends on the process, the risks, and the organization's ability to
exercise oversight.

## Repository-Agent Guidance

AI agents working on this repository should use this framework when interpreting
or changing the project.

When evaluating a proposed feature or design change, ask:

1. **Directive:** What goal or outcome is the system responsible for achieving, and within what scope and constraints?
2. **Context:** What information/environment does the agent need?
3. **Reasoning:** What does it need to figure out?
4. **Agency:** What is it actually allowed to decide or change?
5. **Experimentation:** What can it deliberately test?
6. **Learning:** What evidence should influence future behavior?

For the business-process optimizer, preserve the distinction between:

- the LLM as a reasoning component;
- the agent's delegated agency;
- the workflow policy as the current optimization artifact;
- the simulator as the testbed;
- AutoResearch as the experimentation/search controller;
- Python as the authoritative simulation and evaluation environment.

Do not interpret AutoResearch itself as a maturity stage. It is an experimentation
mechanism that can be used at different levels of agency.
