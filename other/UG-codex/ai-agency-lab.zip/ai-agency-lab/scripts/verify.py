"""Run baseline tests and regenerate the weekly report."""
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
commands = [
    [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'],
    [sys.executable, 'src/sales_lab/report.py'],
]
for command in commands:
    subprocess.run(command, cwd=root, check=True)
print('Verification complete: tests passed and report generated.')
