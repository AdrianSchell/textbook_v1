# Student prompts — aligned with the Executive MBA assignment

These are copies of the prompts in the classroom HTML. Use the HTML copy buttons during class. Follow the stages in order.

## Stage 3 — Assisted: Analyze and advise

Analyze the sales transactions in data/sales.csv and review the existing weekly management report and business context. Identify important sales trends, potential problems, and management questions. Recommend useful actions or additional analysis, explaining your reasoning in business language. You may inspect project files and perform read-only calculations, but do not modify or create files. Do not implement recommendations.

## Stage 4 — Agentic: Produce and verify a management briefing

Produce a management sales briefing for the latest reporting week, using the sales data and the established business context. The briefing must include:

1. Net revenue for the latest week and its change from the previous week.
2. The three products with the lowest net revenue in the latest week.
3. Products whose net revenue declined week over week, with the size of each decline.
4. A concise management summary explaining the most important findings.

Determine and execute the necessary steps independently within these boundaries. Use the available project tools to analyze the data and write the completed briefing to reports/management_briefing.md.

Verify the calculations and the finished briefing. If a calculation or verification fails, investigate and correct the problem before delivering the completed briefing.

Explain how you checked the results and where to find the file.

This is a reporting task, not a request to redesign the reporting application. Do not change the source sales data or application code. Ask before installing additional dependencies.

## Toward Stage 5 — Objective-directed experimentation

Our operational objective is to detect emerging sales problems early while minimizing unnecessary management alerts.

Take responsibility for determining what analytical and reporting work is needed to pursue this objective within the existing sales-reporting workflow. Investigate the current approach, develop and evaluate alternative alerting policies, and determine which approach is best supported by the available evidence.

Develop at least two competing alerting policies, such as a week-over-week decline threshold and a multiweek moving-average rule. Evaluate them on historical sales data using a reproducible chronological backtest and a defensible proxy for future deterioration. Compare missed problems, false alarms, and practical trade-offs. If the available historical data are insufficient for a reliable comparison, explain the limitation rather than claiming that one policy has been conclusively validated.

Recommend the best-supported policy, explain its limitations, and document the evidence and proposed alerting rules in reports/alert_policy_review.md.

Then create reports/objective_driven_briefing.md: a revised version of the Stage 4 management briefing that applies the recommended alerting policy to the available sales data. Adapt the alerts and reporting content to better serve the operational objective. Make the alerts and their rationale clear.

Include a short section explaining exactly what changed from reports/management_briefing.md and how those changes serve the objective. Preserve the original Stage 4 briefing for comparison.

You may create analysis files and new reports within the repository, but do not change the source sales data, the Stage 4 briefing, production systems, or the existing reporting application. Do not activate a recurring alerting process or connect external services. Ask before installing dependencies or taking destructive actions.

### Optional follow-up: Explain your approach

Explain how you determined what work was necessary to pursue the objective, how you developed and evaluated alternative alerting policies, and why you selected your recommendation. What assumptions, risks, and evidence limitations should management consider?
