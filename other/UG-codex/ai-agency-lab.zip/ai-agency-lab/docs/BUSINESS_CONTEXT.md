# Business context — fictional sales reporting

The company sells eight fictional products in four regions. The synthetic transaction dataset covers **78 Monday–Sunday reporting weeks**, ending in October 2026. The business reporting workflow helps executives monitor net revenue, identify weakening performance, and prioritize investigation.

**Net revenue** is `(units - returned_units) * unit_price`; returns are assigned to the same transaction date for teaching simplicity. The data omit taxes, discounts, cost of goods sold, inventory constraints, and actual managerial interventions. Declining sales are a signal to investigate, **not proof** of an underlying business problem.

## Stage 4 management requirements
For the latest reporting week, management requires: net revenue and its week-over-week change; the three products with the lowest net revenue; products with week-over-week net-revenue declines and the size of those declines; and a concise interpretation. The agent must independently produce and verify the briefing without changing the reporting application.

## Stage 5 operational objective
**Detect emerging sales problems early while minimizing unnecessary management alerts.** The agent may compare alerting policies (for example, week-over-week thresholds versus multiweek averages) on chronological historical data and recommend a policy. The agent must define a defensible *proxy* for subsequent deterioration; there is no authoritative ground-truth label for a business problem. The longer synthetic history supports more meaningful comparisons, but backtests remain illustrative; event counts, proxy definitions, policy tuning, and synthetic-data assumptions can materially affect conclusions. A revised management briefing may demonstrate the selected policy, but it is not an authorized recurring deployment.

Do not change original data or connect external business systems. Preserve the Stage 4 briefing for comparison.
