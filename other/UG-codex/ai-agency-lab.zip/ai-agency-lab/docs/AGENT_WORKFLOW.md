# Agent workflow — authority depends on the exercise

1. Confirm the repository root, read `AGENTS.md` and the business context, and inspect relevant files.
2. **Stage 3:** Analyze sales and advise in chat only. Read-only calculations are permitted; file creation and modifications are not.
3. **Stage 4:** Produce the specifically required briefing in `reports/management_briefing.md`; independently calculate, cross-check, and explain the results. Do not edit application code.
4. **Stage 5-oriented:** Define a deterioration proxy, compare at least two policies in a reproducible chronological backtest, and document limitations in `reports/alert_policy_review.md`. Produce a separate `reports/objective_driven_briefing.md` and explain how it differs from the preserved Stage 4 briefing.
5. State which checks actually ran, what evidence supports conclusions, and which risks or approvals remain.

For initial setup only, `uv run python scripts/verify.py` checks the **baseline application** and regenerates `reports/weekly_report.md`. It does not validate Stage 4 or Stage 5 business claims. Standing instructions are not technical permission controls.
