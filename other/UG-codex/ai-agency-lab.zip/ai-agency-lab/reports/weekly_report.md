# Weekly Sales Report

**Period:** 2026-10-05 through 2026-10-11
**Net revenue:** $215,514.00
**Transaction records:** 224

## Revenue by product

- Atlas: $3,636.00
- Beacon: $12,094.50
- Cobalt: $12,978.00
- Delta: $21,318.00
- Echo: $40,710.00
- Flux: $33,879.00
- Grove: $31,434.00
- Harbor: $59,464.50

## Revenue by region

- East: $56,352.00
- North: $49,171.50
- South: $53,455.50
- West: $56,535.00

_Baseline report: descriptive totals only. It does not yet compare weeks or identify emerging risks._
