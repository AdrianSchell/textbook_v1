"""Baseline weekly reporting application. Intentionally simple, but correct."""
import argparse
import csv
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "sales.csv"
OUTPUT = ROOT / "reports" / "weekly_report.md"


def load_sales(path=DATA):
    with Path(path).open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    required = {"date", "product", "region", "units", "unit_price", "returned_units"}
    if not rows or not required.issubset(rows[0]):
        raise ValueError("Sales CSV is empty or missing required columns")
    for row in rows:
        row["date"] = date.fromisoformat(row["date"])
        row["units"] = int(row["units"])
        row["returned_units"] = int(row["returned_units"])
        row["unit_price"] = float(row["unit_price"])
        if not 0 <= row["returned_units"] <= row["units"]:
            raise ValueError("Invalid returns quantity")
    return rows


def net_revenue(row):
    """Returns reduce realized revenue; no tax or shipping modeled."""
    return (row["units"] - row["returned_units"]) * row["unit_price"]


def summarize_week(rows, start):
    end = start + timedelta(days=7)
    selected = [r for r in rows if start <= r["date"] < end]
    by_product = defaultdict(float)
    by_region = defaultdict(float)
    for r in selected:
        by_product[r["product"]] += net_revenue(r)
        by_region[r["region"]] += net_revenue(r)
    return {"start": start, "end": end - timedelta(days=1),
            "revenue": sum(net_revenue(r) for r in selected),
            "transactions": len(selected),
            "by_product": dict(sorted(by_product.items())),
            "by_region": dict(sorted(by_region.items()))}


def render_report(summary):
    lines = ["# Weekly Sales Report", "",
             f"**Period:** {summary['start']} through {summary['end']}",
             f"**Net revenue:** ${summary['revenue']:,.2f}",
             f"**Transaction records:** {summary['transactions']}", "",
             "## Revenue by product", ""]
    for product, revenue in summary["by_product"].items():
        lines.append(f"- {product}: ${revenue:,.2f}")
    lines.extend(["", "## Revenue by region", ""])
    for region, revenue in summary["by_region"].items():
        lines.append(f"- {region}: ${revenue:,.2f}")
    lines.extend(["", "_Baseline report: descriptive totals only. It does not yet compare weeks or identify emerging risks._", ""])
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Generate a baseline weekly sales report")
    parser.add_argument("--week", help="Monday of reporting week (YYYY-MM-DD); defaults to latest week in data")
    parser.add_argument("--data", type=Path, default=DATA)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    rows = load_sales(args.data)
    latest = max(r["date"] for r in rows)
    start = date.fromisoformat(args.week) if args.week else latest - timedelta(days=latest.weekday())
    if start.weekday() != 0:
        parser.error("--week must be a Monday")
    result = summarize_week(rows, start)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(render_report(result), encoding="utf-8")
    print(f"Wrote {args.output} ({result['start']} to {result['end']})")

if __name__ == "__main__":
    main()
