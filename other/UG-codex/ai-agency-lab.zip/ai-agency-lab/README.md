# Executive MBA: Delegating Business Work to Codex

Explore how delegated **responsibility (Directive)** and **authority (Agency)** change as an AI agent moves from advising, to executing a defined business task, to pursuing an operational objective. The agent is Codex; the existing Python reporting application is conventional software. All sales data are fictional.

## Getting started

1. Download and extract the course ZIP. It already contains the top-level folder `ai-agency-lab`; do not create another folder with that name.
2. Install and sign in to the Codex desktop app, then open the **extracted folder containing `AGENTS.md` and `pyproject.toml`** as the project.
3. Ask Codex to check whether `uv` is installed and, if necessary, request approval before installing it via the official method. `uv` manages the Python environment and dependencies and normally coexists with other Python installations.
4. In Codex chat, ask it to confirm the project root and read `AGENTS.md`. Then ask Codex to run the baseline commands below and report their results. You do not need to run them in a separate terminal.

```text
uv run python src/sales_lab/report.py
uv run python -m unittest discover -s tests -v
```

The baseline report is **`reports/weekly_report.md`**. Inspect it before the exercises. A successful software test is not evidence of better business outcomes.

## Classroom exercises

The classroom HTML provides the full instructions and copyable prompts. Matching prompts are available in [`assignments/STUDENT_PROMPTS.md`](assignments/STUDENT_PROMPTS.md).

| Exercise | Manager delegates | Agent may do | Main output |
|---|---|---|---|
| **Stage 3 — Assisted** | Analyze and advise | Inspect and calculate without writing files | Recommendations in chat |
| **Stage 4 — Agentic** | Produce a specified management briefing | Choose analytical steps, calculate, verify, and write the briefing | `reports/management_briefing.md` |
| **Toward Stage 5 — Autonomous** | Pursue earlier detection with fewer false alarms | Compare alert policies, recommend, and adapt the briefing within boundaries | `reports/alert_policy_review.md` and `reports/objective_driven_briefing.md` |

**Stage 4:** Produce the report management specified. **Stage 5-oriented:** Discover how reporting can better achieve the operational objective. The Stage 5 exercise is a bounded historical experiment, not continuous autonomous operation. Preserve the Stage 4 report for comparison.

## Business definitions and guardrails

Net revenue = `(units - returned_units) * unit_price`; weeks run Monday–Sunday. Data cover 78 weeks of synthetic transactions. No authoritative ground-truth labels exist for a real sales problem, so the Stage 5 backtest must define and justify a proxy. No external accounts or APIs are required for the project itself. Do not modify source data or application code in the exercises, activate recurring alerts, or connect production systems.

`AGENTS.md` contains standing agent guidance; it is **not** a technical security boundary. People and organizations retain accountability for the agent's delegated work. On managed devices, follow institutional software-installation policies.

See [`docs/PROJECT_STRUCTURE.md`](docs/PROJECT_STRUCTURE.md) for the directory map and [`docs/BUSINESS_CONTEXT.md`](docs/BUSINESS_CONTEXT.md) for reporting assumptions.
