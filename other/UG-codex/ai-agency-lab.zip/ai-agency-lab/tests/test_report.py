import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import unittest
from datetime import date
from sales_lab.report import net_revenue, summarize_week, render_report, OUTPUT, ROOT, load_sales

class ReportingTests(unittest.TestCase):
    def test_returns_reduce_revenue(self):
        self.assertEqual(net_revenue({"units": 10, "returned_units": 2, "unit_price": 20}), 160)

    def test_baseline_report_path(self):
        self.assertEqual(OUTPUT, ROOT / "reports" / "weekly_report.md")

    def test_latest_week_is_nonempty(self):
        rows = load_sales()
        latest = max(row["date"] for row in rows)
        monday = latest - __import__("datetime").timedelta(days=latest.weekday())
        summary = summarize_week(rows, monday)
        self.assertGreater(summary["revenue"], 0)
        self.assertEqual(len(summary["by_product"]), 8)

    def test_synthetic_history_coverage(self):
        rows = load_sales()
        from datetime import timedelta
        mondays = sorted({row["date"] - timedelta(days=row["date"].weekday()) for row in rows})
        self.assertEqual(len(mondays), 78)
        self.assertEqual(mondays[0], date(2025, 4, 14))
        self.assertEqual(mondays[-1], date(2026, 10, 5))
        self.assertTrue(all((right - left).days == 7 for left, right in zip(mondays, mondays[1:])))

    def test_week_boundaries(self):
        rows = [
            {"date": date(2026, 9, 7), "product": "A", "region": "East", "units": 2, "returned_units": 0, "unit_price": 10},
            {"date": date(2026, 9, 14), "product": "A", "region": "East", "units": 3, "returned_units": 0, "unit_price": 10},
        ]
        summary = summarize_week(rows, date(2026, 9, 7))
        self.assertEqual(summary["revenue"], 20)
        self.assertEqual(summary["transactions"], 1)
        self.assertIn("Weekly Sales Report", render_report(summary))

if __name__ == "__main__":
    unittest.main()
