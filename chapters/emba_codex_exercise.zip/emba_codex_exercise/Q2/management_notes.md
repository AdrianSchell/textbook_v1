# Q2 management notes

Leadership celebrates higher revenue and proposes accelerating expansion. Operations reports carrier disruption, increased overtime, and temporary fulfillment staffing. Finance notes higher freight and returns-processing costs. The causal contribution of each factor is not yet established.

These are fictional teaching data. Do not assume notes are verified facts.
